# Locality Audits, Witness Hashing, and a LocalNOT-to-Monotone Extraction Attempt for NP Circuit Lower Bounds
*(Draft v0.2 — 2025-12-23 — proof attempt; one explicit keystone remains)*

## Abstract
We give a detailed proof attempt toward a nonuniform circuit lower bound for an NP language built from a “SAT-filtered clique” predicate. The strategy is to (i) enforce circuit *structure* via local audit identities (existential self-reduction, witness checking, renaming invariance, and star/pair locality gadgets); (ii) induce **unique witnesses** with noticeable probability using an explicit Valiant–Vazirani hashing lemma with pairwise-independent hashing; (iii) obtain a **LocalNOT** representation; (iv) apply random block restrictions to eliminate negations, extracting a monotone circuit; and (v) contradict known monotone lower bounds for CLIQUE. The Valiant–Vazirani uniqueness lemma and the star/pair local-bit extraction are proved at the level of explicit inequalities. The remaining missing ingredient is a full audit **soundness theorem** that converts approximate identity passing into LocalNOT implementability.

---

## 1. Definitions

### 1.1 The language \(L_{mix}\)
Input:
- A graph \(H\) on \([B]\).
- CNFs \(\Phi=(\phi_1,\dots,\phi_B)\) over disjoint variable sets.

Fix \(t\). Define:
\[
L_{mix}(H;\Phi)=1 \iff \exists C\subseteq[B], |C|=t: C 	ext{ clique in } H \wedge orall i\in C,\ SAT(\phi_i)=1.
\]
This is in NP with witness \(C\) and satisfying assignments for blocks in \(C\).

### 1.2 Substitution graph encoding
For each block \(\phi_i\), build a SAT→CLIQUE gadget \(G_i(\phi_i)\) with 1-gap clique number \(k\) vs \(k-1\).
Let \(G = H[G_1,\dots,G_B]\) (substitution / lexicographic product). Then:
\[
L_{mix}(H;\Phi)=1 \iff \omega(G)\ge t\cdot k
\]
under the 1-gap promise.

### 1.3 Hash-filtered variant \(L_{mix}^{hash}\)
Add seed \(S=(m,A,b)\) defining pairwise-independent hash \(h(C)=A\chi(C)\oplus b\).
Define:
\[
L_{mix}^{hash}(H,\Phi;S)=1 \iff \exists C \in W(H,\Phi): h(C)=0^m
\]
where \(W(H,\Phi)\) is the set of witness cliques.

---

## 2. Two proved modules

### 2.1 VV uniqueness lemma (explicit)
Let \(K=|W|\) and let \(X\) be the number of witnesses surviving the hash filter.
With pairwise independence and choosing \(m\) such that \(2^m\in[K,2K]\), a second-moment argument yields:
\[
\Pr[X=1]\ge 1/8.
\]
Randomizing \(m\) over a logarithmic range yields probability \(\Omega(1/\log K)\) of a unique survivor.

(See thoughts_chaos_18.txt.)

### 2.2 Star/pair local-bit extraction (resampling)
On the star gadget \(H_i(S_0)\), a resampling test that perturbs a random other block \(j
e i\) estimates influence.
Passing implies existence of a block-local predicate \(y_i(\phi_i)\) such that
\(f(H_i(S_0),\Phi)pprox y_i(\phi_i)\).
Pair gadgets \(H_{i,j}(S_0)\) enforce
\(f(H_{i,j}(S_0),\Phi)pprox y_i(\phi_i)\wedge y_j(\phi_j)\).

(See thoughts_chaos_15.txt.)

---

## 3. Proof attempt outline

### 3.1 Audits
We audit a candidate circuit \(f\) (and an associated witness-output procedure) on a distribution over inputs:
- existential self-reduction identities,
- witness verification,
- renaming invariance,
- star/pair locality gadgets,
- VV hash seeds.

### 3.2 Unique-seed focusing
Condition on a hash seed \(S\) that yields a unique surviving witness \(C^*\).
Witness checking forces any accepting computation to output \(C^*\).
Combined with star/pair local bits, acceptance on that slice collapses to an AND of \(y_i\) over \(i\in C^*\),
which is LocalNOT in block metric.

(See thoughts_chaos_19.txt, Chunks 148–151.)

### 3.3 LocalNOT-to-monotone extraction
Given LocalNOT with per-NOT block support \(\le r\), restrict to a random set of blocks \(U\) of size \(m\).
With high probability, all NOTs simplify (their supports intersect the deleted blocks), yielding a monotone circuit
for the restricted instance. Fix all \(\phi_i\) trivial satisfiable and fix the hash to \(m=0\) to recover CLIQUE,
contradicting monotone lower bounds.

(See thoughts_chaos_19.txt, Chunks 152–153.)

---

## 4. The one remaining keystone

### 4.1 Keystone: Audit soundness ⇒ LocalNOT
What remains is a rigorous theorem that passing the audit identities with small error implies the existence
of a LocalNOT circuit family computing \(L_{mix}^{hash}\) (or a function close to it), with polynomial overhead.

Intuitively:
- star/pair audits extract local block goodness bits;
- VV hashing yields unique-witness instances with noticeable probability;
- witness checking forces acceptance to focus on those witnesses;
- SR and renaming prevent nonlocal negation patterns from “cheating” across blocks.

Making this fully formal (and parameterized) is the open part of the attempt.

---

## Appendix: Artifact map
- thoughts_chaos_18.txt: explicit VV uniqueness bound for witness sets via pairwise independence.
- thoughts_chaos_19.txt: full end-to-end contradiction attempt with parameter choices and the keystone isolated.
